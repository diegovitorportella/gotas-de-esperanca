import 'package:flutter/material.dart';
import 'package:gotas_de_esperanca/main_screen.dart';
import 'helpers/database_helper.dart'; // Importar o helper

class CadastroScreen extends StatefulWidget {
  const CadastroScreen({super.key});

  @override
  State<CadastroScreen> createState() => _CadastroScreenState();
}

class _CadastroScreenState extends State<CadastroScreen> {
  // Controladores para os campos de texto
  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  final _dataNascimentoController = TextEditingController();
  String? _tipoSanguineoSelecionado; // Para o Dropdown

  // Chave para o formulário (opcional, mas bom para validação futura)
  final _formKey = GlobalKey<FormState>();

  // Lista de tipos sanguíneos
  final List<String> _tiposSanguineos = [
    'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
  ];

  bool _isLoading = false; // Para mostrar indicador de progresso

  @override
  void dispose() {
    // Limpar os controladores quando a tela for descartada
    _nomeController.dispose();
    _emailController.dispose();
    _senhaController.dispose();
    _dataNascimentoController.dispose();
    super.dispose();
  }

  // Função para lidar com o cadastro
  Future<void> _cadastrar() async {
    // Validação básica (pode ser melhorada)
    if (_nomeController.text.isEmpty ||
        _emailController.text.isEmpty ||
        _senhaController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, preencha nome, e-mail e senha.'), backgroundColor: Colors.orange),
      );
      return;
    }

    setState(() {
      _isLoading = true; // Inicia o carregamento
    });

    try {
      final result = await DatabaseHelper.updateUserProfile(
        nome: _nomeController.text,
        email: _emailController.text,
        senha: _senhaController.text, // !!! NUNCA SALVE SENHA ASSIM EM PRODUÇÃO !!!
        dataNascimento: _dataNascimentoController.text.isNotEmpty ? _dataNascimentoController.text : null,
        tipoSanguineo: _tipoSanguineoSelecionado,
      ); //

      setState(() {
        _isLoading = false; // Finaliza o carregamento
      });

      if (result > 0) { // Verifica se o update foi bem-sucedido (linhas afetadas > 0)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cadastro realizado com sucesso!'), backgroundColor: Colors.green),
        );
        // Navega para a tela principal, removendo as anteriores da pilha
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const MainScreen()),
              (Route<dynamic> route) => false,
        );
      } else {
        // Verifica se o erro foi email duplicado (baseado no debugPrint do helper)
        // Uma abordagem melhor seria o helper retornar um código de erro específico
        if (mounted) { // Garante que o widget ainda está na árvore
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Erro ao cadastrar. O e-mail pode já estar em uso.'), backgroundColor: Colors.red),
          );
        }
      }
    } catch (e) {
      setState(() {
        _isLoading = false; // Finaliza o carregamento em caso de erro
      });
      debugPrint("Erro no cadastro: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ocorreu um erro inesperado durante o cadastro.'), backgroundColor: Colors.red),
        );
      }
    }
  }

  // Função para mostrar o Date Picker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      locale: const Locale('pt', 'BR'), // Para formato de data brasileiro
    );
    if (picked != null) {
      // Formata a data (opcional, pode salvar como ISO se preferir)
      // Exemplo: 'dd/MM/yyyy'
      // Para usar DateFormat, adicione `intl` ao pubspec.yaml se já não estiver
      // import 'package:intl/intl.dart';
      // _dataNascimentoController.text = DateFormat('dd/MM/yyyy').format(picked);

      // Ou simplesmente YYYY-MM-DD
      _dataNascimentoController.text = "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
    }
  }


  @override
  Widget build(BuildContext context) {
    // Configura o locale para pt_BR para o DatePicker
    Locale myLocale = Localizations.localeOf(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Criar Conta'),
        backgroundColor: const Color(0xFFC62828),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        // Usar SingleChildScrollView para evitar overflow com teclado aberto
        child: SingleChildScrollView(
          child: Form( // Opcional: usar Form para validação
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch, // Estica os botões
              children: <Widget>[
                TextFormField(
                  controller: _nomeController,
                  decoration: const InputDecoration(
                    labelText: 'Nome Completo*',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                  keyboardType: TextInputType.name,
                  textCapitalization: TextCapitalization.words,
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'E-mail*',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _senhaController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Senha*',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock_outline),
                  ),
                ),
                const SizedBox(height: 24.0), // Mais espaço
                // Campo Data de Nascimento
                TextFormField(
                  controller: _dataNascimentoController,
                  decoration: InputDecoration(
                      labelText: 'Data de Nascimento (Opcional)',
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.calendar_today_outlined),
                      suffixIcon: IconButton( // Ícone para abrir o calendário
                        icon: const Icon(Icons.edit_calendar),
                        onPressed: () => _selectDate(context),
                      )
                  ),
                  readOnly: true, // Impede digitação direta
                  onTap: () => _selectDate(context), // Abre o calendário ao tocar
                ),
                const SizedBox(height: 16.0),
                // Dropdown Tipo Sanguíneo
                DropdownButtonFormField<String>(
                  value: _tipoSanguineoSelecionado,
                  hint: const Text('Tipo Sanguíneo (Opcional)'),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.bloodtype_outlined),
                  ),
                  items: _tiposSanguineos.map((String tipo) {
                    return DropdownMenuItem<String>(
                      value: tipo,
                      child: Text(tipo),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      _tipoSanguineoSelecionado = newValue;
                    });
                  },
                ),
                const SizedBox(height: 32.0),
                // Botão Cadastrar com indicador de progresso
                _isLoading
                    ? const Center(child: CircularProgressIndicator(color: Color(0xFFC62828)))
                    : ElevatedButton(
                  onPressed: _cadastrar, // Chama a função de cadastro
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFC62828),
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 50),
                    textStyle: const TextStyle(fontSize: 18), // Aumenta a fonte
                  ),
                  child: const Text('Cadastrar'),
                ),
                const SizedBox(height: 16.0),
                Center( // Botão para voltar ao login (caso exista)
                  child: TextButton(
                    onPressed: () => Navigator.pop(context), // Volta para a tela anterior
                    child: const Text('Já tenho conta'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}