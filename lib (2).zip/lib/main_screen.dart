import 'package:flutter/material.dart';
import 'home_screen_app.dart';
import 'mapa_screen.dart';
import 'calendario_screen.dart';
import 'perfil_screen.dart';
import 'models/achievement.dart';
import 'helpers/database_helper.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  bool _isLoadingData = true;

  int _totalDoacoes = 0;
  DateTime? _ultimaDoacao;
  List<Map<String, dynamic>> _lembretes = [];
  String _userName = 'Doador';
  String? _userBloodType;

  // --- 1. ARMAZENA O MAPA COMPLETO DO PERFIL ---
  Map<String, dynamic>? _perfilData;
  // --- FIM DA ADIÇÃO ---


  final List<Achievement> _allAchievements = const [
    Achievement(title: 'Iniciante Solidário', description: 'Você realizou sua primeira doação!', icon: Icons.looks_one, requiredDonations: 1),
    Achievement(title: 'Doador Regular', description: 'Parabéns por doar 3 vezes!', icon: Icons.bookmark, requiredDonations: 3),
    Achievement(title: 'Herói', description: 'Incrível! Você já doou 5 vezes!', icon: Icons.shield, requiredDonations: 5),
    Achievement(title: 'Lenda', description: 'Você é uma lenda da doação com 10 contribuições!', icon: Icons.star, requiredDonations: 10),
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoadingData = true;
    });
    try {
      final perfilData = await DatabaseHelper.getPerfil();
      final lembretesData = await DatabaseHelper.getLembretes();

      setState(() {
        if (perfilData != null) {
          // --- 2. SALVA O MAPA NO ESTADO ---
          _perfilData = perfilData;
          // --- FIM DA ADIÇÃO ---

          _totalDoacoes = perfilData['totalDoacoes'] ?? 0;
          final ultimaDoacaoStr = perfilData['ultimaDoacao'];
          _ultimaDoacao = ultimaDoacaoStr != null ? DateTime.tryParse(ultimaDoacaoStr) : null;
          _userName = perfilData['nome'] ?? 'Doador';
          _userBloodType = perfilData['tipoSanguineo'];
        }
        _lembretes = lembretesData;
        _isLoadingData = false;
      });
    } catch (e) {
      debugPrint("Erro ao carregar dados: $e");
      setState(() {
        _isLoadingData = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Erro ao carregar os dados salvos.')),
        );
      }
    }
  }

  // ... (Funções _registrarNovaDoacao, _showCelebrationDialog, _adicionarLembrete, _removerLembrete, _navigateToTab não precisam de alteração) ...
  Future<void> _registrarNovaDoacao() async {
    final oldTotal = _totalDoacoes;
    final newTotal = oldTotal + 1;
    final newUltimaDoacao = DateTime.now();
    Achievement? unlockedAchievement;

    for (var achievement in _allAchievements) {
      if (newTotal >= achievement.requiredDonations && oldTotal < achievement.requiredDonations) {
        unlockedAchievement = achievement;
        break;
      }
    }

    await DatabaseHelper.updatePerfilDoacao(newTotal, newUltimaDoacao);

    setState(() {
      _totalDoacoes = newTotal;
      _ultimaDoacao = newUltimaDoacao;
    });

    _showCelebrationDialog(newTotal, unlockedAchievement);
  }

  Future<void> _showCelebrationDialog(int newTotal, Achievement? unlockedAchievement) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.favorite, color: Colors.red, size: 60),
              const SizedBox(height: 16),
              Text(
                'Parabéns pela sua ${newTotal}ª doação!',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text('O seu gesto de solidariedade salva vidas. Muito obrigado!', textAlign: TextAlign.center),
              if (unlockedAchievement != null) ...[
                const Divider(height: 32),
                const Text('Você desbloqueou uma nova conquista:', textAlign: TextAlign.center),
                const SizedBox(height: 8),
                Text(
                  unlockedAchievement.title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFFC62828)),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              child: const Text('Fantástico!'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _adicionarLembrete(String data, String local, String hora) async {
    await DatabaseHelper.createLembrete(data, local, hora);
    _loadData();
  }

  Future<void> _removerLembrete(int id) async {
    await DatabaseHelper.deleteLembrete(id);
    _loadData();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Agendamento removido.')),
      );
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  void _navigateToTab(int index) {
    _onItemTapped(index);
  }


  // --- INÍCIO DA CORREÇÃO ---
  // Este método substitui a lista "widgetOptions".
  // Ele constrói APENAS o widget que está ativo.
  Widget _buildCurrentScreen() {
    switch (_selectedIndex) {
      case 0: // Início
        return HomeScreenApp(
          userName: _userName,
          ultimaDoacao: _ultimaDoacao,
          onNavigate: _navigateToTab,
        );
      case 1: // Locais
      // A MapaScreen só será construída (e seu initState executado)
      // quando o usuário clicar no índice 1.
        return const MapaScreen();
      case 2: // Calendário
        return CalendarioScreen(
          lembretes: _lembretes,
          onSchedule: _adicionarLembrete,
          onRemoveLembrete: _removerLembrete,
        );
      case 3: // Perfil
        return PerfilScreen(
          userName: _userName,
          userBloodType: _userBloodType,
          totalDoacoes: _totalDoacoes,
          ultimaDoacao: _ultimaDoacao,
          onRegistrarNovaDoacao: _registrarNovaDoacao,
          allAchievements: _allAchievements,
          perfilData: _perfilData,
          onProfileUpdated: _loadData,
        );
      default:
      // Caso seguro, não deve acontecer
        return Container();
    }
  }

  @override
  Widget build(BuildContext context) {
    // A lista 'widgetOptions' foi removida daqui.

    return Scaffold(
      body: Center(
        child: _isLoadingData
            ? const CircularProgressIndicator(color: Color(0xFFC62828))
        // O body agora chama o método que constrói a tela correta
            : _buildCurrentScreen(),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Início'),
          BottomNavigationBarItem(icon: Icon(Icons.location_on_outlined), label: 'Locais'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Calendário'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Perfil'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: const Color(0xFFC62828),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        showUnselectedLabels: true,
        // É importante manter o 'type' como 'fixed' para
        // que a barra de navegação funcione corretamente com essa abordagem.
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
// --- FIM DA CORREÇÃO ---
}