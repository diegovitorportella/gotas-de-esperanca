import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
// 1. Remova a importação do login_screen
// import 'login_screen.dart';
// 2. Adicione a importação do splash_screen
import 'splash_screen.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() {
  initializeDateFormatting('pt_BR', null).then((_) {
    Intl.defaultLocale = 'pt_BR';
    runApp(const GotasDeEsperancaApp());
  });
}

class GotasDeEsperancaApp extends StatelessWidget {
  const GotasDeEsperancaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: const Locale('pt', 'BR'),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('pt', 'BR'),
      ],

      // 3. Altere o 'home' para a SplashScreen
      home: const SplashScreen(),
    );
  }
}