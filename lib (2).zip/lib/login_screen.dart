import 'package:flutter/material.dart';
import 'package:gotas_de_esperanca/main_screen.dart';
import 'cadastro_screen.dart';
import 'helpers/database_helper.dart';
// 1. ADICIONE A IMPORTAÇÃO
import 'package:shared_preferences/shared_preferences.dart';

// 1. A classe LoginScreen agora é 'const' e apenas cria o estado.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

// 2. Toda a lógica, variáveis e o método 'build' foram movidos para cá.
class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _senhaController.dispose();
    super.dispose(); // Agora isso é válido
  }

  Future<void> _login() async {
    // 'context' e 'mounted' estão disponíveis aqui
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // 'setState' está disponível aqui
    setState(() {
      _isLoading = true;
    });

    try {
      final perfilData = await DatabaseHelper.getPerfil();
      if (perfilData == null) {
        _showErrorSnackbar('Nenhum usuário cadastrado.');
        setState(() {
          _isLoading = false;
        });
        return;
      }

      final storedEmail = perfilData['email'];
      final storedSenha = perfilData['senha'];

      final enteredEmail = _emailController.text;
      final enteredSenha = _senhaController.text;

      if (storedEmail != null &&
          storedSenha != null &&
          storedEmail == enteredEmail &&
          storedSenha == enteredSenha) {
        // --- 2. SALVA O ESTADO DE LOGIN ---
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isLoggedIn', true);
        // --- FIM DA ADIÇÃO ---

        // Use 'context' para navegar
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const MainScreen()),
        );
      } else {
        _showErrorSnackbar('E-mail ou senha inválidos.');
      }
    } catch (e) {
      debugPrint("Erro no login: $e");
      _showErrorSnackbar('Ocorreu um erro ao tentar fazer login.');
    } finally {
      // 'mounted' está disponível aqui
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showErrorSnackbar(String message) {
    // 'mounted' e 'context' estão disponíveis aqui
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), backgroundColor: Colors.red),
      );
    }
  }

  // 3. O método 'build' também fica dentro da classe State.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Image.asset(
                  'assets/images/logo_app.png',
                  height: 120,
                ),
                const SizedBox(height: 16.0),
                Text(
                  'Gotas de Esperança',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 28.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
                const SizedBox(height: 40.0),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'E-mail',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty || !value.contains('@')) {
                      return 'Por favor, insira um e-mail válido.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _senhaController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Senha',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock_outline),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Por favor, insira sua senha.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 32.0),
                _isLoading
                    ? const Center(
                    child: CircularProgressIndicator(
                        color: Color(0xFFC62828)))
                    : ElevatedButton(
                  onPressed: _login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFC62828),
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 50),
                    textStyle: const TextStyle(fontSize: 18),
                  ),
                  child: const Text('Entrar'),
                ),
                const SizedBox(height: 16.0),
                Center(
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const CadastroScreen()),
                      );
                    },
                    child: const Text('Criar conta'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}