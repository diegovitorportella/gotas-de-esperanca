import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'models/achievement.dart';
import 'sobre_app_screen.dart';
import 'widgets/achievement_widget.dart';
import 'login_screen.dart';
// 1. ADICIONAR IMPORTAÇÕES
import 'package:shared_preferences/shared_preferences.dart';
import 'editar_perfil_screen.dart'; // Para a nova tela

class PerfilScreen extends StatelessWidget {
  final int totalDoacoes;
  final DateTime? ultimaDoacao;
  final VoidCallback onRegistrarNovaDoacao;
  final List<Achievement> allAchievements;
  final String userName;
  final String? userBloodType;

  // --- 2. RECEBE O MAPA E A FUNÇÃO DE CALLBACK ---
  final Map<String, dynamic>? perfilData;
  final VoidCallback onProfileUpdated;

  const PerfilScreen({
    super.key,
    required this.totalDoacoes,
    required this.ultimaDoacao,
    required this.onRegistrarNovaDoacao,
    required this.allAchievements,
    required this.userName,
    required this.userBloodType,
    required this.perfilData, // Adicionado
    required this.onProfileUpdated, // Adicionado
  });

  String get proximaDoacao {
    // ... (sem alteração) ...
    if (ultimaDoacao == null) {
      return 'Você já pode doar!';
    }
    final proximaData = ultimaDoacao!.add(const Duration(days: 60));
    final hoje = DateTime.now();

    if (proximaData.isBefore(hoje)) {
      return 'Você já pode doar!';
    } else {
      return 'A partir de ${DateFormat('dd \'de\' MMMM \'de\' yyyy', 'pt_BR').format(proximaData)}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meu Perfil'),
        backgroundColor: const Color(0xFFC62828),
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // ... (Avatar e Nome - sem alteração) ...
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.grey.shade200,
                child: Icon(Icons.person, size: 60, color: Colors.grey.shade800),
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: Text(userName, style: const TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 32),
            _buildInfoRow(
                icon: Icons.bloodtype,
                label: 'Tipo Sanguíneo',
                value: userBloodType ?? 'Não informado'
            ),
            const SizedBox(height: 16),
            _buildInfoRow(icon: Icons.calendar_today, label: 'Próxima Doação', value: proximaDoacao),
            const SizedBox(height: 16),
            _buildInfoRow(icon: Icons.favorite, label: 'Total de Doações', value: '$totalDoacoes doações'),
            const SizedBox(height: 32),

            // --- 3. ADICIONADO BOTÃO "EDITAR PERFIL" ---
            OutlinedButton.icon(
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Editar Meu Perfil'),
              onPressed: () async {
                if (perfilData == null) return; // Não faz nada se os dados não carregaram

                // Navega para a tela de edição
                final bool? foiAtualizado = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditarPerfilScreen(
                      perfilData: perfilData!,
                    ),
                  ),
                );

                // Se a tela de edição retornou 'true', chama a função para recarregar
                if (foiAtualizado == true && context.mounted) {
                  onProfileUpdated();
                }
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.grey.shade800,
                side: BorderSide(color: Colors.grey.shade400),
                minimumSize: const Size(double.infinity, 50),
              ),
            ),
            const SizedBox(height: 16),
            // --- FIM DA ADIÇÃO ---

            ElevatedButton(
              onPressed: onRegistrarNovaDoacao,
              // ... (estilo sem alteração) ...
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD32F2F),
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text('Registrei uma nova doação!'),
            ),
            const Divider(height: 40),
            Text('Minhas Conquistas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey.shade800)),
            const SizedBox(height: 24),
            GridView.builder(
              // ... (sem alteração) ...
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 16, mainAxisSpacing: 16),
              itemCount: allAchievements.length,
              itemBuilder: (context, index) {
                final achievement = allAchievements[index];
                final isUnlocked = totalDoacoes >= achievement.requiredDonations;
                return AchievementWidget(achievement: achievement, isUnlocked: isUnlocked);
              },
            ),
            const SizedBox(height: 24),
            ListTile(
              // ... (Botão "Sobre o App" sem alteração) ...
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.info_outline, color: Color(0xFFC62828)),
              title: const Text('Sobre o Gotas de Esperança'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SobreAppScreen()),
                );
              },
            ),
            const SizedBox(height: 24),
            Center(
              child: TextButton(
                // --- 4. ATUALIZAÇÃO DO BOTÃO "SAIR" (LOGOUT) ---
                onPressed: () async {
                  // Limpa o estado de login
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('isLoggedIn', false);

                  if (context.mounted) {
                    // Envia o usuário de volta para o Login
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => const LoginScreen()),
                          (Route<dynamic> route) => false,
                    );
                  }
                },
                // --- FIM DA ATUALIZAÇÃO ---
                child: const Text('Sair', style: TextStyle(color: Colors.red, fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow({required IconData icon, required String label, required String value}) {
    // ... (sem alteração) ...
    return Row(
      children: [
        Icon(icon, color: const Color(0xFFC62828)),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 14)),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
          ],
        )
      ],
    );
  }
}